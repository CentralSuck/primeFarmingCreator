
files {
    'html/index.html',
    'html/style.css',
    'html/main.js',
}

client_scripts {
    'client.lua'
}

ui_page 'html/index.html'

export "drawBar"