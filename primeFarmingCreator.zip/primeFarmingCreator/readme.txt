

Installation:
1) Put the resource in your resource folder
2) Setup the config.lua
3) run the sql.sql in your database
4) start pogressBar before primeFarmingCreator in your server.cfg

Depedencies:
- ESX
- pogressBar (Download in Discord #downloads)

For Support and Updates join our Discord Server:
https://dsc.gg/primeScripts
