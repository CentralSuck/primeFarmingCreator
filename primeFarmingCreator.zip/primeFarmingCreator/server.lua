local ESX = nil
TriggerEvent('esx:getSharedObject', function(obj)
    ESX = obj
end)

RegisterNetEvent('primeFarmingCreator:harvest')
AddEventHandler('primeFarmingCreator:harvest', function(item, amount, duration)

    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)
    
    --TriggerClientEvent('esx:showNotification', source, 'Event triggered')
    
    if xPlayer.canCarryItem(item, amount) then
        Citizen.Wait(duration)
        xPlayer.addInventoryItem(item, amount)
    else
        TriggerClientEvent('esx:showNotification', source, Translation[Config.Locale]['inventory_full'])
    end
    
end)

RegisterNetEvent('primeFarmingCreator:Process')
AddEventHandler('primeFarmingCreator:Process', function(ProcessItemName, ProcessItemAmount, ProcessedItemName, ProcessedItemAmount, duration, ProcessItemLabel)

    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)

    --TriggerClientEvent('esx:showNotification', source, 'Event triggered')

    local hasItem = xPlayer.getInventoryItem(ProcessItemName).count

    if hasItem >= ProcessItemAmount then
        TriggerClientEvent('pogressBar:drawBar', source, duration, ProcessItemLabel)
        Citizen.Wait(duration)
        xPlayer.removeInventoryItem(ProcessItemName, ProcessItemAmount)
        xPlayer.addInventoryItem(ProcessedItemName, ProcessedItemAmount)
    else
        TriggerClientEvent('esx:showNotification', source, Translation[Config.Locale]['not_enough'] .. ProcessItemLabel)
    end

end)

RegisterNetEvent('primeFarmingCreator:Sell')
AddEventHandler('primeFarmingCreator:Sell', function(ItemSellName, ItemSellLabel, SellItemAmount, duration, payment)

    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)

    --TriggerClientEvent('esx:showNotification', source, 'Event triggered')

    local getItem = xPlayer.getInventoryItem(ItemSellName).count

    if getItem >= SellItemAmount then
        Citizen.CreateThread(function()
            while getItem >= SellItemAmount do

                local getSellItem = xPlayer.getInventoryItem(ItemSellName).count
                
                if getSellItem >= SellItemAmount then
                    xPlayer.removeInventoryItem(ItemSellName, SellItemAmount)
                    xPlayer.addAccountMoney(Config.useAccount, payment)
                else
                    TriggerClientEvent('esx:showNotification', source, Translation[Config.Locale]['doesnt_have'] .. ItemSellLabel)
                end

                Citizen.Wait(100)
            end
        end)
    else
        TriggerClientEvent('esx:showNotification', source, Translation[Config.Locale]['doesnt_have'] .. ItemSellLabel)
    end

end)