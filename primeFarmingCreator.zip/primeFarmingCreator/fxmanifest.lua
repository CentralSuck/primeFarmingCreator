fx_version 'cerulean'
game 'gta5'

author 'primeScripts'
description 'primeFarmingCreator'
version '1.0.0'

lua54 'yes'

client_scripts {
    'config.lua',
    'client.lua'
}
server_scripts {
    'config.lua',
    'server.lua'
}

escrow_ignore {
    'config.lua',
    'client.lua',
    'server.lua',
}