Config = {}
Translation = {}


Config.Currency = '$'
Config.useAccount = 'money'
Config.Locale = 'en'


 -- All Farming Areas: You can easily create custom Farming Areas!
Config.FarmingAreas = {
    {label = 'Apple Field', 
        x = 2381.0107, y = 4702.7354, z = 33.9663, rot = 83.4056, 
        blip = true, blipId = 164, blipcolour = 1, blipsize = 1.0,
        marker = false, markerType = 27, markerScale = 3.0, R = 0, G = 128, B = 255, opacity = 50,
        ped = false, pedModel = 'csb_trafficwarden', 
        animation = true, lib = 'amb@prop_human_bum_bin@base', anim = 'base', -- Animationlist: https://wiki.gtanet.work/index.php?title=Animations
        helpnotify = 'Press ~r~E~s~, to collect ~r~Apples~s~.',
        maxDistance = 7.0,
        item = 'apple', amount = math.random(1,2), duration = 3000, -- duration in milliseconds
    },

    {label = 'Grape Plantation',
        x = 2247.1489, y = 4772.7437, z = 39.9289, rot = 321.2376,
        blip = true, blipId = 164, blipcolour = 7, blipsize = 1.0,
        marker = false, markerType = 27, markerScale = 3.0, R = 0, G = 128, B = 255, opacity = 50,
        ped = false, pedModel = 'csb_trafficwarden', 
        animation = true, lib = 'amb@prop_human_bum_bin@base', anim = 'base', -- Animationlist: https://wiki.gtanet.work/index.php?title=Animations
        helpnotify = 'Press ~p~E~s~, to collect ~p~Grapes~s~.',
        maxDistance = 10.0,
        item = 'grapes', amount = math.random(1,2), duration = 3000, -- duration in milliseconds
    }
}


-- Processor Area: Create easily custom Processor Areas!
Config.Processor = {
    {label = 'Apple Mixer', 
        x = 1477.5635, y = 2723.1228, z = 37.5895, rot = 32.6353, 
        blip = true, blipId = 479, blipcolour = 2, blipsize = 0.9,
        marker = false, markerType = 27, markerScale = 3.0, R = 0, G = 128, B = 255, opacity = 50,
        ped = true, pedModel = 'csb_trafficwarden', 
        animation = true, lib = 'amb@prop_human_bum_bin@base', anim = 'base',
        helpnotify = 'Press ~r~E~s~, to mix ~r~Apples~s~.',
        maxDistance = 3.0,
        ProcessItemName = 'apple', ProcessItemLabel = 'Apple', ProcessItemAmount = 2, duration = 3000, -- duration in milliseconds
        ProcessedItemName = 'applejuice', ProcessedItemLabel = 'Applejuice', ProcessedItemAmount = 1,
    },

    {label = 'Grape Processor', 
        x = 2473.9458, y = 4445.2134, z = 35.4165, rot = 272.3038, 
        blip = true, blipId = 479, blipcolour = 2, blipsize = 0.9,
        marker = false, markerType = 27, markerScale = 3.0, R = 0, G = 128, B = 255, opacity = 50,
        ped = true, pedModel = 'csb_trafficwarden', 
        animation = true, lib = 'clothingtie', anim = 'try_tie_neutral_a',
        helpnotify = 'Press ~p~E~s~, to process ~p~Grapes~s~.',
        maxDistance = 3.0,
        ProcessItemName = 'grapes', ProcessItemLabel = 'Grapes', ProcessItemAmount = 2, duration = 3000, -- duration in milliseconds
        ProcessedItemName = 'grapejuice', ProcessedItemLabel = 'Grapejuice', ProcessedItemAmount = 1,
    },
}


-- Seller Area: Create easily custom Seller Areas!
Config.Seller = {
    {label = 'Applejuice Seller', 
        x = 1930.2817, y = 4635.8789, z = 40.4551, rot = 1.7502, 
        blip = true, blipId = 478, blipcolour = 2, blipsize = 0.9,
        marker = false, markerType = 27, markerScale = 3.0, R = 0, G = 128, B = 255, opacity = 50,
        ped = true, pedModel = 'csb_trafficwarden',        -- Pedmodels: https://docs.fivem.net/docs/game-references/ped-models/
        animation = true, lib = 'clothingtie', anim = 'try_tie_neutral_a',      -- Animationlist: https://wiki.gtanet.work/index.php?title=Animations
        helpnotify = 'Press ~r~E~s~, to sell ~r~Applejuice~s~.',
        maxDistance = 3.0,
        ItemSellName = 'applejuice', ItemSellLabel = 'Applejuice', SellItemAmount = 2, duration = 3000,     -- duration in milliseconds
        payment = 900,
    },

    {label = 'Grapejuice Seller', 
        x = 1797.1786, y = 4592.3145, z = 37.6828, rot = 182.2135, 
        blip = true, blipId = 478, blipcolour = 7, blipsize = 0.9,
        marker = false, markerType = 27, markerScale = 3.0, R = 0, G = 128, B = 255, opacity = 50,
        ped = true, pedModel = 'csb_trafficwarden',        -- Pedmodels: https://docs.fivem.net/docs/game-references/ped-models/
        animation = true, lib = 'clothingtie', anim = 'try_tie_neutral_a',      -- Animationlist: https://wiki.gtanet.work/index.php?title=Animations
        helpnotify = 'Press ~p~E~s~, to sell ~p~Grapejuice~s~.',
        maxDistance = 3.0,
        ItemSellName = 'grapejuice', ItemSellLabel = 'Grapejuice', SellItemAmount = 2, duration = 3000,     -- duration in milliseconds
        payment = 900,
    },
}



Translation = {
    ['de'] = {
        ['inventory_full'] = '~r~Dein Inventar ist voll!',
        ['not_enough'] = '~r~Du hast nicht genug ',
        ['doesnt_have'] = '~r~Du hast kein '
    },
    ['en'] = {
        ['inventory_full'] = '~r~Your Inventory is full!',
        ['not_enough'] = '~r~You dont have enough ',
        ['doesnt_have'] = '~r~You dont have '
    }
}

