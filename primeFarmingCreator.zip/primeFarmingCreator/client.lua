ESX = nil
Citizen.CreateThread(function()
    while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
        Citizen.Wait(0)
    end
end)

local isDoing = false

for k, v in pairs(Config.FarmingAreas) do

    Citizen.CreateThread(function()
        while true do

            local playerPed = PlayerPedId()
            local playerCoords = GetEntityCoords(playerPed)
            local distance = Vdist(playerCoords, v.x, v.y, v.z)

            if distance <= v.maxDistance then
                ESX.ShowHelpNotification(v.helpnotify)
                if IsControlJustReleased(0, 38) and isDoing == false then
                    isDoing = true
                    TriggerServerEvent('primeFarmingCreator:harvest', v.item, v.amount, v.duration)
                    if v.animation then
                        local playerPed = PlayerPedId()
                        ESX.Streaming.RequestAnimDict(v.lib, function()
                            TaskPlayAnim(playerPed, v.lib, v.anim, 8.0, 1.0, -1, 49, 0, false, false, false)
                            RemoveAnimDict(v.lib)
                        end)
                        Citizen.Wait(v.duration)
                        ClearPedTasks(playerPed)
                    end
                    Citizen.Wait(v.duration)
                    isDoing = false
                end
            end

            Citizen.Wait(1)
        end
    end)

    if v.ped then

        local isNearPed = false
        local isAtPed = false
        local isPedLoaded = false
        local npc

        Citizen.CreateThread(function()
            while true do
        
                local playerPed = PlayerPedId()
                local playerCoords = GetEntityCoords(playerPed)

                local pedDistance = Vdist(playerCoords, v.x, v.y, v.z)
                isNearPed = false
                isAtPed = false

                if pedDistance < 20.0 then
                    isNearPed = true
                    if not isPedLoaded then
                        RequestModel(GetHashKey(v.pedModel))
                        while not HasModelLoaded(GetHashKey(v.pedModel)) do
                            Wait(10)
                        end

                        local npc = CreatePed(4, GetHashKey(v.pedModel), v.x, v.y, v.z - 1.0, v.rot, false, false)
                        FreezeEntityPosition(npc, true)
                        SetEntityHeading(npc, v.rot)
                        SetEntityInvincible(npc, true)
                        SetBlockingOfNonTemporaryEvents(npc, true)

                        isPedLoaded = true
                    end
                end

                if isPedLoaded and not isNearPed then
                    DeleteEntity(npc)
                    SetModelAsNoLongerNeeded(GetHashKey(v.pedModel))
                    isPedLoaded = false
                end

                if pedDistance < 2.0 then
                    isAtPed = true
                end

                Citizen.Wait(500)
            end
        end)
    end

    if v.marker then
        Citizen.CreateThread(function()
            while true do

                DrawMarker(v.markerType, v.x, v.y, v.z - 0.9, 0.0, 0.0, 0.0, 0.0, 180.0, 0.0, v.markerScale, v.markerScale, v.markerScale, v.R, v.G, v.B, v.opacity, false, true, 2, nil, nil, false)

                Citizen.Wait(1)
            end
        end)
    end

    if v.blip then
        v.blip = AddBlipForCoord(v.x, v.y)
        SetBlipSprite(v.blip, v.blipId)
        SetBlipDisplay(v.blip, 4)
        SetBlipScale(v.blip, v.blipsize)
        SetBlipColour(v.blip, v.blipcolour)
        SetBlipAsShortRange(v.blip, true)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString(v.label)
        EndTextCommandSetBlipName(v.blip)
    end

end

for k, v in pairs(Config.Processor) do

    Citizen.CreateThread(function()
        while true do

            local playerPed = PlayerPedId()
            local playerCoords = GetEntityCoords(playerPed)
            local distance = Vdist(playerCoords, v.x, v.y, v.z)

            if distance <= v.maxDistance then
                ESX.ShowHelpNotification(v.helpnotify)
                if IsControlJustReleased(0, 38) and isDoing == false then
                    isDoing = true
                    TriggerServerEvent('primeFarmingCreator:Process', v.ProcessItemName, v.ProcessItemAmount, v.ProcessedItemName, v.ProcessedItemAmount, v.duration, v.ProcessItemLabel)
                    if v.animation then
                        local playerPed = PlayerPedId()
                        ESX.Streaming.RequestAnimDict(v.lib, function()
                            TaskPlayAnim(playerPed, v.lib, v.anim, 8.0, 1.0, -1, 49, 0, false, false, false)
                            RemoveAnimDict(v.lib)
                        end)
                        Citizen.Wait(1000)
                        ClearPedTasks(playerPed)
                    end
                    Citizen.Wait(v.duration)
                    isDoing = false
                end
            end

            Citizen.Wait(1)
        end
    end)

    if v.ped then

        local isNearPed = false
        local isAtPed = false
        local isPedLoaded = false
        local npc

        Citizen.CreateThread(function()
            while true do
        
                local playerPed = PlayerPedId()
                local playerCoords = GetEntityCoords(playerPed)

                local pedDistance = Vdist(playerCoords, v.x, v.y, v.z)
                isNearPed = false
                isAtPed = false

                if pedDistance < 20.0 then
                    isNearPed = true
                    if not isPedLoaded then
                        RequestModel(GetHashKey(v.pedModel))
                        while not HasModelLoaded(GetHashKey(v.pedModel)) do
                            Wait(10)
                        end

                        local npc = CreatePed(4, GetHashKey(v.pedModel), v.x, v.y, v.z - 1.0, v.rot, false, false)
                        FreezeEntityPosition(npc, true)
                        SetEntityHeading(npc, v.rot)
                        SetEntityInvincible(npc, true)
                        SetBlockingOfNonTemporaryEvents(npc, true)

                        isPedLoaded = true
                    end
                end

                if isPedLoaded and not isNearPed then
                    DeleteEntity(npc)
                    SetModelAsNoLongerNeeded(GetHashKey(v.pedModel))
                    isPedLoaded = false
                end

                if pedDistance < 2.0 then
                    isAtPed = true
                end

                Citizen.Wait(500)
            end
        end)
    end

    if v.marker then
        Citizen.CreateThread(function()
            while true do

                DrawMarker(v.markerType, v.x, v.y, v.z - 0.9, 0.0, 0.0, 0.0, 0.0, 180.0, 0.0, v.markerScale, v.markerScale, v.markerScale, v.R, v.G, v.B, v.opacity, false, true, 2, nil, nil, false)

                Citizen.Wait(1)
            end
        end)
    end

    if v.blip then
        v.blip = AddBlipForCoord(v.x, v.y)
        SetBlipSprite(v.blip, v.blipId)
        SetBlipDisplay(v.blip, 4)
        SetBlipScale(v.blip, v.blipsize)
        SetBlipColour(v.blip, v.blipcolour)
        SetBlipAsShortRange(v.blip, true)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString(v.label)
        EndTextCommandSetBlipName(v.blip)
    end

end

for k, v in pairs(Config.Seller) do

    Citizen.CreateThread(function()
        while true do

            local playerPed = PlayerPedId()
            local playerCoords = GetEntityCoords(playerPed)
            local distance = Vdist(playerCoords, v.x, v.y, v.z)

            if distance <= v.maxDistance then
                ESX.ShowHelpNotification(v.helpnotify)
                if IsControlJustReleased(0, 38) and isDoing == false then
                    if v.animation then
                        local playerPed = PlayerPedId()
                        ESX.Streaming.RequestAnimDict(v.lib, function()
                            TaskPlayAnim(playerPed, v.lib, v.anim, 8.0, 1.0, -1, 49, 0, false, false, false)
                            RemoveAnimDict(v.lib)
                        end)
                        Citizen.Wait(1000)
                        ClearPedTasks(playerPed)
                    end
                    isDoing = true
                    TriggerServerEvent('primeFarmingCreator:Sell', v.ItemSellName, v.ItemSellLabel, v.SellItemAmount, v.duration, v.payment)
                    Citizen.Wait(v.duration)
                    isDoing = false
                end
            end

            Citizen.Wait(1)
        end
    end)

    if v.ped then

        local isNearPed = false
        local isAtPed = false
        local isPedLoaded = false
        local npc

        Citizen.CreateThread(function()
            while true do
        
                local playerPed = PlayerPedId()
                local playerCoords = GetEntityCoords(playerPed)

                local pedDistance = Vdist(playerCoords, v.x, v.y, v.z)
                isNearPed = false
                isAtPed = false

                if pedDistance < 20.0 then
                    isNearPed = true
                    if not isPedLoaded then
                        RequestModel(GetHashKey(v.pedModel))
                        while not HasModelLoaded(GetHashKey(v.pedModel)) do
                            Wait(10)
                        end

                        local npc = CreatePed(4, GetHashKey(v.pedModel), v.x, v.y, v.z - 1.0, v.rot, false, false)
                        FreezeEntityPosition(npc, true)
                        SetEntityHeading(npc, v.rot)
                        SetEntityInvincible(npc, true)
                        SetBlockingOfNonTemporaryEvents(npc, true)

                        isPedLoaded = true
                    end
                end

                if isPedLoaded and not isNearPed then
                    DeleteEntity(npc)
                    SetModelAsNoLongerNeeded(GetHashKey(v.pedModel))
                    isPedLoaded = false
                end

                if pedDistance < 2.0 then
                    isAtPed = true
                end

                Citizen.Wait(500)
            end
        end)
    end

    if v.marker then
        Citizen.CreateThread(function()
            while true do

                DrawMarker(v.markerType, v.x, v.y, v.z - 0.9, 0.0, 0.0, 0.0, 0.0, 180.0, 0.0, v.markerScale, v.markerScale, v.markerScale, v.R, v.G, v.B, v.opacity, false, true, 2, nil, nil, false)

                Citizen.Wait(1)
            end
        end)
    end

    if v.blip then
        v.blip = AddBlipForCoord(v.x, v.y)
        SetBlipSprite(v.blip, v.blipId)
        SetBlipDisplay(v.blip, 4)
        SetBlipScale(v.blip, v.blipsize)
        SetBlipColour(v.blip, v.blipcolour)
        SetBlipAsShortRange(v.blip, true)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString(v.label)
        EndTextCommandSetBlipName(v.blip)
    end

end

function ShowNotification(text)
    SetNotificationTextEntry('STRING')
    AddTextComponentString(text)
    DrawNotification(false, true)
end