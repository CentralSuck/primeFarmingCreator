INSERT INTO `items` (name, label, weight, rare, can_remove) VALUES
	('apple', 'Apple', 1, 0, 1),
    ('applejuice', 'Applejuice', 1, 0, 1),
    ('grapes', 'Grapes', 1, 0, 1),
    ('grapejuice', 'Grapejuice', 1, 0, 1)
;